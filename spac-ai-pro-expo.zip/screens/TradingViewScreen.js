import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { WebView } from 'react-native-webview';

const { width } = Dimensions.get('window');

const symbols = [
  { symbol: 'ES=F', name: 'S&P 500', tvSymbol: 'NASDAQ:ES=F' },
  { symbol: 'NQ=F', name: 'Nasdaq', tvSymbol: 'NASDAQ:NQ=F' },
  { symbol: 'YM=F', name: 'Dow Jones', tvSymbol: 'NASDAQ:YM=F' },
  { symbol: 'CL=F', name: 'Crude Oil', tvSymbol: 'NYMEX:CL=F' },
  { symbol: 'GC=F', name: 'Gold', tvSymbol: 'COMEX:GC=F' },
  { symbol: 'CCIV', name: 'Lucid', tvSymbol: 'NASDAQ:CCIV' },
  { symbol: 'PSTH', name: 'PSTH', tvSymbol: 'NASDAQ:PSTH' },
  { symbol: 'TSLA', name: 'Tesla', tvSymbol: 'NASDAQ:TSLA' },
  { symbol: 'AAPL', name: 'Apple', tvSymbol: 'NASDAQ:AAPL' },
];

export default function TradingViewScreen() {
  const [selectedSymbol, setSelectedSymbol] = useState(symbols[0]);
  const [interval, setInterval] = useState('60');
  const webViewRef = useRef(null);

  const generateHTML = () => {
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <script src="https://s3.tradingview.com/tv.js"></script>
          <style>
            body { margin: 0; padding: 0; background: #0a0e1a; }
            #tv_chart_container { height: 100vh; width: 100%; }
          </style>
        </head>
        <body>
          <div id="tv_chart_container"></div>
          <script>
            new TradingView.widget({
              container_id: 'tv_chart_container',
              symbol: '${selectedSymbol.tvSymbol}',
              interval: '${interval}',
              timezone: 'Etc/UTC',
              theme: 'dark',
              style: '1',
              locale: 'en',
              toolbar_bg: '#f1f3f6',
              enable_publishing: false,
              hide_side_toolbar: false,
              allow_symbol_change: true,
              studies: ['RSI@tv-basicstudies', 'MACD@tv-basicstudies'],
              height: '100%',
              width: '100%',
              withdateranges: true,
              details: true,
              calendar: true
            });
          </script>
        </body>
      </html>
    `;
  };

  return (
    <View style={styles.container}>
      {/* Symbol Selector */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.symbolSelector}>
        {symbols.map((item, index) => (
          <TouchableOpacity
            key={index}
            style={[
              styles.symbolButton,
              selectedSymbol.symbol === item.symbol && styles.symbolButtonActive
            ]}
            onPress={() => setSelectedSymbol(item)}
          >
            <Text style={[
              styles.symbolText,
              selectedSymbol.symbol === item.symbol && styles.symbolTextActive
            ]}>
              {item.symbol}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Interval Selector */}
      <View style={styles.intervalSelector}>
        {['1', '5', '15', '60', '240', 'D'].map((tf) => (
          <TouchableOpacity
            key={tf}
            style={[styles.intervalButton, interval === tf && styles.intervalButtonActive]}
            onPress={() => setInterval(tf)}
          >
            <Text style={[styles.intervalText, interval === tf && styles.intervalTextActive]}>
              {tf === 'D' ? 'يومي' : tf === '240' ? '4س' : tf === '60' ? '1س' : tf === '15' ? '15د' : tf === '5' ? '5د' : '1د'}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* TradingView Chart */}
      <WebView
        ref={webViewRef}
        source={{ html: generateHTML() }}
        style={styles.webview}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        startInLoadingState={true}
        scalesPageToFit={true}
      />

      {/* Quick Info */}
      <View style={styles.infoBar}>
        <Text style={styles.infoSymbol}>{selectedSymbol.symbol}</Text>
        <Text style={styles.infoName}>{selectedSymbol.name}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0e1a' },
  symbolSelector: { paddingHorizontal: 16, paddingVertical: 12, maxHeight: 60 },
  symbolButton: {
    backgroundColor: '#1f2937',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 12,
    marginRight: 8,
    borderWidth: 1,
    borderColor: '#374151',
  },
  symbolButtonActive: {
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
    borderColor: '#10b981',
  },
  symbolText: { color: '#9ca3af', fontWeight: 'bold', fontSize: 13 },
  symbolTextActive: { color: '#10b981' },
  intervalSelector: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingBottom: 12,
    gap: 8,
  },
  intervalButton: {
    backgroundColor: '#1f2937',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#374151',
  },
  intervalButtonActive: {
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
    borderColor: '#10b981',
  },
  intervalText: { color: '#9ca3af', fontSize: 12 },
  intervalTextActive: { color: '#10b981', fontWeight: 'bold' },
  webview: { flex: 1, backgroundColor: '#0a0e1a' },
  infoBar: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#111827',
    borderTopWidth: 1,
    borderTopColor: '#1f2937',
  },
  infoSymbol: { color: '#fff', fontWeight: 'bold', fontSize: 16, marginRight: 8 },
  infoName: { color: '#9ca3af', fontSize: 14 },
});