import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function HomeScreen({ navigation }) {
  const stats = [
    { title: 'قيمة المحفظة', value: '$24,580', change: '+$2,450', icon: '💰', color: '#10b981' },
    { title: 'صفقات مفتوحة', value: '5', change: '3 رابحة', icon: '📈', color: '#f59e0b' },
    { title: 'تنبيهات جديدة', value: '3', change: 'آخر تحديث: الآن', icon: '🔔', color: '#8b5cf6' },
    { title: 'دقة AI', value: '78%', change: 'آخر 30 يوم', icon: '🤖', color: '#3b82f6' },
  ];

  return (
    <ScrollView style={styles.container}>
      <LinearGradient colors={['#0a0e1a', '#111827']} style={styles.gradient}>
        <Text style={styles.title}>SPAC AI Pro</Text>
        <Text style={styles.subtitle}>منصة التداول الذكية</Text>

        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          {stats.map((stat, index) => (
            <TouchableOpacity key={index} style={[styles.statCard, { borderColor: stat.color }]}>
              <Text style={styles.statIcon}>{stat.icon}</Text>
              <Text style={styles.statTitle}>{stat.title}</Text>
              <Text style={[styles.statValue, { color: stat.color }]}>{stat.value}</Text>
              <Text style={styles.statChange}>{stat.change}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => navigation.navigate('TradingView')}
          >
            <LinearGradient colors={['#3b82f6', '#8b5cf6']} style={styles.actionGradient}>
              <Text style={styles.actionIcon}>📈</Text>
              <Text style={styles.actionText}>TradingView Pro</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity 
            style={styles.actionButton}
            onPress={() => navigation.navigate('Portfolio')}
          >
            <LinearGradient colors={['#10b981', '#059669']} style={styles.actionGradient}>
              <Text style={styles.actionIcon}>💼</Text>
              <Text style={styles.actionText}>المحفظة</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Recent Alerts */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>🔔 آخر التنبيهات</Text>
            <TouchableOpacity onPress={() => navigation.navigate('Alerts')}>
              <Text style={styles.seeAll}>عرض الكل ←</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.alertItem}>
            <Text style={styles.alertIcon}>🎯</Text>
            <View style={styles.alertContent}>
              <Text style={styles.alertTitle}>CCIV وصل للهدف 1</Text>
              <Text style={styles.alertDesc}>الربح: +$1,250 (+15.3%)</Text>
            </View>
            <Text style={styles.alertTime}>قبل 5 دقائق</Text>
          </View>

          <View style={styles.alertItem}>
            <Text style={styles.alertIcon}>⚠️</Text>
            <View style={styles.alertContent}>
              <Text style={styles.alertTitle}>CL=F اقترب من وقف الخسارة</Text>
              <Text style={styles.alertDesc}>المسافة: 0.5%</Text>
            </View>
            <Text style={styles.alertTime}>قبل 12 دقيقة</Text>
          </View>
        </View>
      </LinearGradient>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0e1a' },
  gradient: { flex: 1, padding: 20 },
  title: { fontSize: 28, fontWeight: 'bold', color: '#fff', textAlign: 'center', marginTop: 20 },
  subtitle: { fontSize: 14, color: '#9ca3af', textAlign: 'center', marginBottom: 30 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 20 },
  statCard: {
    backgroundColor: 'rgba(17, 24, 39, 0.7)',
    borderRadius: 16,
    padding: 16,
    width: '48%',
    borderWidth: 1,
    borderColor: '#374151',
  },
  statIcon: { fontSize: 24, marginBottom: 8 },
  statTitle: { fontSize: 12, color: '#9ca3af', marginBottom: 4 },
  statValue: { fontSize: 20, fontWeight: 'bold', marginBottom: 2 },
  statChange: { fontSize: 11, color: '#10b981' },
  quickActions: { flexDirection: 'row', gap: 12, marginBottom: 24 },
  actionButton: { flex: 1, borderRadius: 16, overflow: 'hidden' },
  actionGradient: { padding: 20, alignItems: 'center' },
  actionIcon: { fontSize: 32, marginBottom: 8 },
  actionText: { color: '#fff', fontWeight: 'bold', fontSize: 14 },
  section: { backgroundColor: 'rgba(17, 24, 39, 0.7)', borderRadius: 16, padding: 16 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#fff' },
  seeAll: { color: '#10b981', fontSize: 13 },
  alertItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(16, 185, 129, 0.1)',
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
    borderRightWidth: 3,
    borderRightColor: '#10b981',
  },
  alertIcon: { fontSize: 24, marginRight: 12 },
  alertContent: { flex: 1 },
  alertTitle: { color: '#fff', fontWeight: 'bold', fontSize: 14 },
  alertDesc: { color: '#9ca3af', fontSize: 12, marginTop: 2 },
  alertTime: { color: '#6b7280', fontSize: 11 },
});