import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch, Modal, TextInput, Alert } from 'react-native';
import * as Notifications from 'expo-notifications';

export default function AlertsScreen({ alerts, setAlerts, saveData }) {
  const [modalVisible, setModalVisible] = useState(false);
  const [newAlert, setNewAlert] = useState({
    symbol: '',
    condition: 'above',
    price: '',
  });

  const [settings, setSettings] = useState({
    targetAlerts: true,
    stopLossAlerts: true,
    aiAlerts: true,
  });

  const addAlert = async () => {
    if (!newAlert.symbol || !newAlert.price) {
      Alert.alert('خطأ', 'يرجى ملء جميع الحقول');
      return;
    }

    const alert = {
      id: Date.now().toString(),
      ...newAlert,
      price: parseFloat(newAlert.price),
      active: true,
      createdAt: new Date().toISOString(),
    };

    const updatedAlerts = [...alerts, alert];
    setAlerts(updatedAlerts);
    saveData('alerts', updatedAlerts);
    setModalVisible(false);
    setNewAlert({ symbol: '', condition: 'above', price: '' });

    // جدولة إشعار
    await Notifications.scheduleNotificationAsync({
      content: {
        title: 'تم إنشاء تنبيه جديد',
        body: `${alert.symbol} ${alert.condition === 'above' ? 'فوق' : 'تحت'} $${alert.price}`,
      },
      trigger: null,
    });
  };

  const toggleAlert = (id) => {
    const updatedAlerts = alerts.map(alert =>
      alert.id === id ? { ...alert, active: !alert.active } : alert
    );
    setAlerts(updatedAlerts);
    saveData('alerts', updatedAlerts);
  };

  const deleteAlert = (id) => {
    const updatedAlerts = alerts.filter(alert => alert.id !== id);
    setAlerts(updatedAlerts);
    saveData('alerts', updatedAlerts);
  };

  return (
    <ScrollView style={styles.container}>
      {/* Settings */}
      <View style={styles.settingsCard}>
        <Text style={styles.settingsTitle}>⚙️ إعدادات التنبيهات</Text>

        <View style={styles.settingRow}>
          <Text style={styles.settingLabel}>🔔 تنبيهات الهدف</Text>
          <Switch
            value={settings.targetAlerts}
            onValueChange={(value) => setSettings({ ...settings, targetAlerts: value })}
            trackColor={{ false: '#374151', true: '#10b981' }}
            thumbColor="#fff"
          />
        </View>

        <View style={styles.settingRow}>
          <Text style={styles.settingLabel}>⚠️ تنبيهات وقف الخسارة</Text>
          <Switch
            value={settings.stopLossAlerts}
            onValueChange={(value) => setSettings({ ...settings, stopLossAlerts: value })}
            trackColor={{ false: '#374151', true: '#10b981' }}
            thumbColor="#fff"
          />
        </View>

        <View style={styles.settingRow}>
          <Text style={styles.settingLabel}>🤖 تنبيهات AI</Text>
          <Switch
            value={settings.aiAlerts}
            onValueChange={(value) => setSettings({ ...settings, aiAlerts: value })}
            trackColor={{ false: '#374151', true: '#10b981' }}
            thumbColor="#fff"
          />
        </View>
      </View>

      {/* Add Alert Button */}
      <TouchableOpacity style={styles.addButton} onPress={() => setModalVisible(true)}>
        <Text style={styles.addButtonText}>+ إنشاء تنبيه جديد</Text>
      </TouchableOpacity>

      {/* Active Alerts */}
      <Text style={styles.sectionTitle}>🔔 التنبيهات النشطة ({alerts.filter(a => a.active).length})</Text>

      {alerts.length === 0 ? (
        <View style={styles.emptyState}>
          <Text style={styles.emptyIcon}>🔔</Text>
          <Text style={styles.emptyText}>لا توجد تنبيهات</Text>
          <Text style={styles.emptySubtext}>أضف تنبيهاً جديداً للبدء</Text>
        </View>
      ) : (
        alerts.map((alert) => (
          <View key={alert.id} style={[styles.alertCard, !alert.active && styles.alertInactive]}>
            <View style={styles.alertHeader}>
              <View>
                <Text style={styles.alertSymbol}>{alert.symbol}</Text>
                <Text style={styles.alertCondition}>
                  {alert.condition === 'above' ? '🔺 فوق' : '🔻 تحت'} ${alert.price}
                </Text>
              </View>
              <View style={styles.alertActions}>
                <Switch
                  value={alert.active}
                  onValueChange={() => toggleAlert(alert.id)}
                  trackColor={{ false: '#374151', true: '#10b981' }}
                  thumbColor="#fff"
                />
                <TouchableOpacity onPress={() => deleteAlert(alert.id)}>
                  <Text style={styles.deleteButton}>🗑️</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        ))
      )}

      {/* Add Alert Modal */}
      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>إنشاء تنبيه جديد</Text>

            <TextInput
              style={styles.input}
              placeholder="رمز السهم (مثال: AAPL)"
              placeholderTextColor="#6b7280"
              value={newAlert.symbol}
              onChangeText={(text) => setNewAlert({ ...newAlert, symbol: text.toUpperCase() })}
            />

            <View style={styles.conditionSelector}>
              <TouchableOpacity
                style={[styles.conditionButton, newAlert.condition === 'above' && styles.conditionButtonActive]}
                onPress={() => setNewAlert({ ...newAlert, condition: 'above' })}
              >
                <Text style={styles.conditionText}>🔺 فوق</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.conditionButton, newAlert.condition === 'below' && styles.conditionButtonActive]}
                onPress={() => setNewAlert({ ...newAlert, condition: 'below' })}
              >
                <Text style={styles.conditionText}>🔻 تحت</Text>
              </TouchableOpacity>
            </View>

            <TextInput
              style={styles.input}
              placeholder="السعر"
              placeholderTextColor="#6b7280"
              keyboardType="numeric"
              value={newAlert.price}
              onChangeText={(text) => setNewAlert({ ...newAlert, price: text })}
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.modalButton} onPress={() => setModalVisible(false)}>
                <Text style={styles.modalButtonText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.modalButton, styles.modalButtonPrimary]} onPress={addAlert}>
                <Text style={[styles.modalButtonText, { color: '#fff' }]}>إنشاء</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0e1a', padding: 16 },
  settingsCard: {
    backgroundColor: 'rgba(17, 24, 39, 0.7)',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
  },
  settingsTitle: { fontSize: 16, fontWeight: 'bold', color: '#fff', marginBottom: 16 },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#1f2937',
  },
  settingLabel: { color: '#fff', fontSize: 14 },
  addButton: {
    backgroundColor: '#8b5cf6',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 24,
  },
  addButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#fff', marginBottom: 12 },
  emptyState: { alignItems: 'center', paddingVertical: 40 },
  emptyIcon: { fontSize: 48, marginBottom: 12 },
  emptyText: { color: '#fff', fontSize: 18, fontWeight: 'bold', marginBottom: 4 },
  emptySubtext: { color: '#9ca3af', fontSize: 14 },
  alertCard: {
    backgroundColor: 'rgba(17, 24, 39, 0.7)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderRightWidth: 4,
    borderRightColor: '#8b5cf6',
  },
  alertInactive: { opacity: 0.5 },
  alertHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  alertSymbol: { fontSize: 18, fontWeight: 'bold', color: '#fff' },
  alertCondition: { fontSize: 14, color: '#9ca3af', marginTop: 4 },
  alertActions: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  deleteButton: { fontSize: 20 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#111827', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24 },
  modalTitle: { fontSize: 20, fontWeight: 'bold', color: '#fff', marginBottom: 20, textAlign: 'center' },
  input: {
    backgroundColor: '#1f2937',
    borderRadius: 12,
    padding: 16,
    color: '#fff',
    fontSize: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#374151',
  },
  conditionSelector: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  conditionButton: {
    flex: 1,
    backgroundColor: '#1f2937',
    padding: 12,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#374151',
  },
  conditionButtonActive: { backgroundColor: 'rgba(139, 92, 246, 0.2)', borderColor: '#8b5cf6' },
  conditionText: { color: '#fff', fontWeight: 'bold' },
  modalButtons: { flexDirection: 'row', gap: 12, marginTop: 20 },
  modalButton: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    backgroundColor: '#1f2937',
  },
  modalButtonPrimary: { backgroundColor: '#8b5cf6' },
  modalButtonText: { color: '#9ca3af', fontWeight: 'bold', fontSize: 16 },
});