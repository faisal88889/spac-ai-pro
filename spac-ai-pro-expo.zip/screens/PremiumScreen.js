import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Linking } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function PremiumScreen() {
  const plans = [
    {
      name: 'مجانية',
      price: '$0',
      period: '/شهر',
      features: ['3 إشارات يومياً', 'محفظة أساسية', 'تنبيهات محدودة'],
      color: '#6b7280',
      popular: false,
    },
    {
      name: 'الذهبية',
      price: '$99',
      period: '/شهر',
      features: ['إشارات غير محدودة', 'تنبيهات فورية', 'محفظة متقدمة', 'تحليل AI'],
      color: '#f59e0b',
      popular: true,
    },
    {
      name: 'الملكية VIP',
      price: '$299',
      period: '/شهر',
      features: ['كل مميزات الذهبية', 'محلل شخصي', 'مكالمات أسبوعية', 'دعم 24/7'],
      color: '#8b5cf6',
      popular: false,
    },
  ];

  const subscribe = (planName) => {
    const message = encodeURIComponent(`أريد الاشتراك في خطة ${planName}`);
    Linking.openURL(`https://wa.me/966508355838?text=${message}`);
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>⭐ خطط الاشتراك</Text>
      <Text style={styles.subtitle}>اختر الخطة المناسبة لك</Text>

      {plans.map((plan, index) => (
        <View key={index} style={[styles.planCard, plan.popular && styles.planCardPopular]}>
          {plan.popular && (
            <View style={styles.popularBadge}>
              <Text style={styles.popularText}>الأكثر شعبية 🔥</Text>
            </View>
          )}

          <Text style={[styles.planName, { color: plan.color }]}>{plan.name}</Text>

          <View style={styles.priceRow}>
            <Text style={styles.planPrice}>{plan.price}</Text>
            <Text style={styles.planPeriod}>{plan.period}</Text>
          </View>

          <View style={styles.featuresList}>
            {plan.features.map((feature, idx) => (
              <View key={idx} style={styles.featureRow}>
                <Text style={styles.featureCheck}>✓</Text>
                <Text style={styles.featureText}>{feature}</Text>
              </View>
            ))}
          </View>

          <TouchableOpacity onPress={() => subscribe(plan.name)}>
            <LinearGradient
              colors={plan.popular ? ['#f59e0b', '#ef4444'] : ['#374151', '#4b5563']}
              style={styles.subscribeButton}
            >
              <Text style={styles.subscribeText}>
                {plan.price === '$0' ? 'الخطة الحالية' : 'اشترك الآن'}
              </Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      ))}

      <View style={styles.contactCard}>
        <Text style={styles.contactTitle}>💬 تحتاج مساعدة؟</Text>
        <Text style={styles.contactText}>تواصل معنا مباشرة عبر واتساب</Text>
        <TouchableOpacity onPress={() => Linking.openURL('https://wa.me/966508355838')}>
          <LinearGradient colors={['#25D366', '#128C7E']} style={styles.whatsappButton}>
            <Text style={styles.whatsappText}>تواصل واتساب</Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0e1a', padding: 16 },
  title: { fontSize: 28, fontWeight: 'bold', color: '#fff', textAlign: 'center', marginTop: 20 },
  subtitle: { fontSize: 14, color: '#9ca3af', textAlign: 'center', marginBottom: 30 },
  planCard: {
    backgroundColor: 'rgba(17, 24, 39, 0.7)',
    borderRadius: 20,
    padding: 24,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#374151',
  },
  planCardPopular: { borderColor: '#f59e0b', borderWidth: 2 },
  popularBadge: {
    position: 'absolute',
    top: -12,
    alignSelf: 'center',
    backgroundColor: '#f59e0b',
    paddingHorizontal: 16,
    paddingVertical: 4,
    borderRadius: 20,
  },
  popularText: { color: '#fff', fontWeight: 'bold', fontSize: 12 },
  planName: { fontSize: 22, fontWeight: 'bold', textAlign: 'center', marginBottom: 8 },
  priceRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'baseline', marginBottom: 20 },
  planPrice: { fontSize: 36, fontWeight: 'bold', color: '#fff' },
  planPeriod: { fontSize: 14, color: '#9ca3af', marginLeft: 4 },
  featuresList: { marginBottom: 24 },
  featureRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  featureCheck: { color: '#10b981', fontSize: 16, marginRight: 8 },
  featureText: { color: '#fff', fontSize: 14 },
  subscribeButton: { padding: 16, borderRadius: 12, alignItems: 'center' },
  subscribeText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  contactCard: {
    backgroundColor: 'rgba(17, 24, 39, 0.7)',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    marginTop: 10,
  },
  contactTitle: { fontSize: 18, fontWeight: 'bold', color: '#fff', marginBottom: 8 },
  contactText: { fontSize: 14, color: '#9ca3af', marginBottom: 16 },
  whatsappButton: { paddingHorizontal: 32, paddingVertical: 12, borderRadius: 12 },
  whatsappText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});