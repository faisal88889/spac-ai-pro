import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Modal, TextInput, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function PortfolioScreen({ portfolio, setPortfolio, saveData }) {
  const [modalVisible, setModalVisible] = useState(false);
  const [newTrade, setNewTrade] = useState({
    symbol: '',
    type: 'شراء',
    quantity: '',
    entryPrice: '',
    currentPrice: '',
  });

  const addTrade = () => {
    if (!newTrade.symbol || !newTrade.quantity || !newTrade.entryPrice) {
      Alert.alert('خطأ', 'يرجى ملء جميع الحقول');
      return;
    }

    const trade = {
      id: Date.now().toString(),
      ...newTrade,
      quantity: parseFloat(newTrade.quantity),
      entryPrice: parseFloat(newTrade.entryPrice),
      currentPrice: parseFloat(newTrade.currentPrice) || parseFloat(newTrade.entryPrice),
      date: new Date().toISOString().split('T')[0],
      status: 'open',
    };

    const updatedPortfolio = [...portfolio, trade];
    setPortfolio(updatedPortfolio);
    saveData('portfolio', updatedPortfolio);
    setModalVisible(false);
    setNewTrade({ symbol: '', type: 'شراء', quantity: '', entryPrice: '', currentPrice: '' });
  };

  const closeTrade = (id) => {
    const updatedPortfolio = portfolio.map(trade => 
      trade.id === id ? { ...trade, status: 'closed' } : trade
    );
    setPortfolio(updatedPortfolio);
    saveData('portfolio', updatedPortfolio);
  };

  const calculatePnL = (trade) => {
    const pnl = (trade.currentPrice - trade.entryPrice) * trade.quantity;
    const pnlPercent = ((trade.currentPrice - trade.entryPrice) / trade.entryPrice) * 100;
    return { pnl, pnlPercent };
  };

  const totalInvestment = portfolio.reduce((sum, t) => sum + (t.entryPrice * t.quantity), 0);
  const totalValue = portfolio.reduce((sum, t) => sum + (t.currentPrice * t.quantity), 0);
  const totalPnL = totalValue - totalInvestment;
  const totalPnLPercent = totalInvestment > 0 ? (totalPnL / totalInvestment) * 100 : 0;

  const openTrades = portfolio.filter(t => t.status === 'open');
  const closedTrades = portfolio.filter(t => t.status === 'closed');

  return (
    <ScrollView style={styles.container}>
      {/* Summary */}
      <LinearGradient colors={['#10b98120', '#05966920']} style={styles.summaryCard}>
        <Text style={styles.summaryTitle}>ملخص المحفظة</Text>
        <View style={styles.summaryRow}>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>إجمالي الاستثمار</Text>
            <Text style={styles.summaryValue}>${totalInvestment.toFixed(2)}</Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>القيمة الحالية</Text>
            <Text style={[styles.summaryValue, { color: '#10b981' }]}>${totalValue.toFixed(2)}</Text>
          </View>
        </View>
        <View style={styles.summaryRow}>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>إجمالي الربح/خسارة</Text>
            <Text style={[styles.summaryValue, { color: totalPnL >= 0 ? '#10b981' : '#ef4444' }]}>
              {totalPnL >= 0 ? '+' : ''}${totalPnL.toFixed(2)}
            </Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>نسبة العائد</Text>
            <Text style={[styles.summaryValue, { color: totalPnL >= 0 ? '#10b981' : '#ef4444' }]}>
              {totalPnLPercent >= 0 ? '+' : ''}{totalPnLPercent.toFixed(2)}%
            </Text>
          </View>
        </View>
      </LinearGradient>

      {/* Add Trade Button */}
      <TouchableOpacity style={styles.addButton} onPress={() => setModalVisible(true)}>
        <LinearGradient colors={['#10b981', '#059669']} style={styles.addButtonGradient}>
          <Text style={styles.addButtonText}>+ إضافة صفقة جديدة</Text>
        </LinearGradient>
      </TouchableOpacity>

      {/* Open Trades */}
      <Text style={styles.sectionTitle}>📈 الصفقات المفتوحة ({openTrades.length})</Text>
      {openTrades.map((trade) => {
        const { pnl, pnlPercent } = calculatePnL(trade);
        return (
          <View key={trade.id} style={[styles.tradeCard, { borderRightColor: pnl >= 0 ? '#10b981' : '#ef4444' }]}>
            <View style={styles.tradeHeader}>
              <View>
                <Text style={styles.tradeSymbol}>{trade.symbol}</Text>
                <Text style={styles.tradeType}>{trade.type} • {trade.quantity} سهم</Text>
              </View>
              <TouchableOpacity onPress={() => closeTrade(trade.id)}>
                <Text style={styles.closeButton}>إغلاق</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.tradeDetails}>
              <View style={styles.tradeDetail}>
                <Text style={styles.tradeLabel}>الدخول</Text>
                <Text style={styles.tradeValue}>${trade.entryPrice}</Text>
              </View>
              <View style={styles.tradeDetail}>
                <Text style={styles.tradeLabel}>الحالي</Text>
                <Text style={styles.tradeValue}>${trade.currentPrice}</Text>
              </View>
              <View style={styles.tradeDetail}>
                <Text style={styles.tradeLabel}>الربح/خسارة</Text>
                <Text style={[styles.tradeValue, { color: pnl >= 0 ? '#10b981' : '#ef4444' }]}>
                  {pnl >= 0 ? '+' : ''}${pnl.toFixed(2)}
                </Text>
              </View>
              <View style={styles.tradeDetail}>
                <Text style={styles.tradeLabel}>%</Text>
                <Text style={[styles.tradeValue, { color: pnl >= 0 ? '#10b981' : '#ef4444' }]}>
                  {pnlPercent >= 0 ? '+' : ''}{pnlPercent.toFixed(2)}%
                </Text>
              </View>
            </View>
          </View>
        );
      })}

      {/* Closed Trades */}
      {closedTrades.length > 0 && (
        <>
          <Text style={styles.sectionTitle}>📋 الصفقات المغلقة ({closedTrades.length})</Text>
          {closedTrades.map((trade) => (
            <View key={trade.id} style={[styles.tradeCard, { opacity: 0.6, borderRightColor: '#6b7280' }]}>
              <View style={styles.tradeHeader}>
                <View>
                  <Text style={styles.tradeSymbol}>{trade.symbol}</Text>
                  <Text style={styles.tradeType}>{trade.type} • {trade.quantity} سهم</Text>
                </View>
                <Text style={styles.closedBadge}>مغلقة</Text>
              </View>
            </View>
          ))}
        </>
      )}

      {/* Add Trade Modal */}
      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>إضافة صفقة جديدة</Text>

            <TextInput
              style={styles.input}
              placeholder="رمز السهم (مثال: AAPL)"
              placeholderTextColor="#6b7280"
              value={newTrade.symbol}
              onChangeText={(text) => setNewTrade({ ...newTrade, symbol: text.toUpperCase() })}
            />

            <View style={styles.typeSelector}>
              <TouchableOpacity
                style={[styles.typeButton, newTrade.type === 'شراء' && styles.typeButtonActive]}
                onPress={() => setNewTrade({ ...newTrade, type: 'شراء' })}
              >
                <Text style={styles.typeText}>شراء</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.typeButton, newTrade.type === 'بيع' && styles.typeButtonActive]}
                onPress={() => setNewTrade({ ...newTrade, type: 'بيع' })}
              >
                <Text style={styles.typeText}>بيع</Text>
              </TouchableOpacity>
            </View>

            <TextInput
              style={styles.input}
              placeholder="الكمية"
              placeholderTextColor="#6b7280"
              keyboardType="numeric"
              value={newTrade.quantity}
              onChangeText={(text) => setNewTrade({ ...newTrade, quantity: text })}
            />

            <TextInput
              style={styles.input}
              placeholder="سعر الدخول"
              placeholderTextColor="#6b7280"
              keyboardType="numeric"
              value={newTrade.entryPrice}
              onChangeText={(text) => setNewTrade({ ...newTrade, entryPrice: text })}
            />

            <TextInput
              style={styles.input}
              placeholder="السعر الحالي (اختياري)"
              placeholderTextColor="#6b7280"
              keyboardType="numeric"
              value={newTrade.currentPrice}
              onChangeText={(text) => setNewTrade({ ...newTrade, currentPrice: text })}
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.modalButton} onPress={() => setModalVisible(false)}>
                <Text style={styles.modalButtonText}>إلغاء</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.modalButton, styles.modalButtonPrimary]} onPress={addTrade}>
                <Text style={[styles.modalButtonText, { color: '#fff' }]}>إضافة</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0e1a', padding: 16 },
  summaryCard: { borderRadius: 16, padding: 20, marginBottom: 20, borderWidth: 1, borderColor: '#10b98150' },
  summaryTitle: { fontSize: 18, fontWeight: 'bold', color: '#fff', marginBottom: 16 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
  summaryItem: { flex: 1 },
  summaryLabel: { fontSize: 12, color: '#9ca3af', marginBottom: 4 },
  summaryValue: { fontSize: 20, fontWeight: 'bold', color: '#fff' },
  addButton: { borderRadius: 12, overflow: 'hidden', marginBottom: 24 },
  addButtonGradient: { padding: 16, alignItems: 'center' },
  addButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#fff', marginBottom: 12 },
  tradeCard: {
    backgroundColor: 'rgba(17, 24, 39, 0.7)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderRightWidth: 4,
  },
  tradeHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  tradeSymbol: { fontSize: 18, fontWeight: 'bold', color: '#fff' },
  tradeType: { fontSize: 12, color: '#9ca3af', marginTop: 2 },
  closeButton: { color: '#ef4444', fontSize: 14, fontWeight: 'bold' },
  closedBadge: { color: '#6b7280', fontSize: 12 },
  tradeDetails: { flexDirection: 'row', justifyContent: 'space-between' },
  tradeDetail: { alignItems: 'center' },
  tradeLabel: { fontSize: 11, color: '#9ca3af', marginBottom: 4 },
  tradeValue: { fontSize: 14, fontWeight: 'bold', color: '#fff' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#111827', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24 },
  modalTitle: { fontSize: 20, fontWeight: 'bold', color: '#fff', marginBottom: 20, textAlign: 'center' },
  input: {
    backgroundColor: '#1f2937',
    borderRadius: 12,
    padding: 16,
    color: '#fff',
    fontSize: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#374151',
  },
  typeSelector: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  typeButton: {
    flex: 1,
    backgroundColor: '#1f2937',
    padding: 12,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#374151',
  },
  typeButtonActive: { backgroundColor: 'rgba(16, 185, 129, 0.2)', borderColor: '#10b981' },
  typeText: { color: '#fff', fontWeight: 'bold' },
  modalButtons: { flexDirection: 'row', gap: 12, marginTop: 20 },
  modalButton: {
    flex: 1,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    backgroundColor: '#1f2937',
  },
  modalButtonPrimary: { backgroundColor: '#10b981' },
  modalButtonText: { color: '#9ca3af', fontWeight: 'bold', fontSize: 16 },
});